// Global packages
let _ = require("underscore");
let Cookies = require("cookies");
let fs = require('fs-extra');
let got = require('got');
let Keygrip = require("keygrip");
let http = require('http');
let Python = require('python-shell');
let sjcl = require('sjcl');
// No authentication required requests
let allowed = '.css .js .png'.split(' ');
// Path to web files no trailing slash
let home = '/home/bot/web';
// Whether or not to console log status and errors
let debugmode = true;
// Initial settings. False means new key setup
let accountinfo = false;

let data = {
  settings: {}
};
// Common pages
let pages = {
  setup: '/setup.html',
  login: '/login.html',
  dashboard: '/dashboard.html'
};
// If cookies get deleted & accountinfo saved, you can log back in without starting the app again
let botrunning = false;
// Random key to protect setup form
let adminkey = '9f521bfac069b197ebb04563ffb4366f7644cdd8faed1136b05cbb07890d15028804456af985833191e6f2c4668cde4af193af448f042974ba50ff5d3603943c';
// Change cookies info if new domain
let cookiename = 'lbcbot_dev';
let cookiedomain = 'lbcbot.com';
// Save settings and accountinfo to current working directory. async is important for speed
async function save_info() {
  try {
    if (accountinfo.passkey) {
      await fs.writeJson('accountinfo.json', accountinfo);
      await fs.writeJson('settings.json', data);
      return true;
    }
    else return false;
  } catch(err) {
    debg('Saving account data failed...');
    accountinfo = false;
    return false;
  }
}
// Load info. If accountinfo blank leave blank
async function load_info() {
  try {
    let ai = await fs.readJson('accountinfo.json');
    if (Object.keys(ai).length > 0) accountinfo = ai;
    let st = await fs.readJson('settings.json');
    data = st;
    return false;
  } catch(err) {
    return false;
  }
}

// Attempt load info at start of app.
load_info();

http.createServer(function (request, response) {
  let cookies = new Cookies(request, response, {
		"keys": Keygrip(["SEKRIT2", "SEKRIT1"], 'sha256', 'hex')
	});
	if (!accountinfo.accesstoken) {
    if (request.method === "POST") {
      let b = '';
      request.on('data', function(d) {b += d});
      request.on('end', function() {
        try {
          // parse new accountinfo
          let ad = JSON.parse(b);
          if (ad.adminkey === adminkey) {
            accountinfo = ad;
            send_data(response, request, false);
          }
          else throw "Invalid.";
        } catch(e) {
          debg(e);
          send_text('Something went wrong.' + e, response);
        }
      });
    }
    if (request.method === "GET") {
	    request.url = pages.setup;
	    send_data(response, request, false);
    }
	}
	else {
	  // Cookie name. Signed = true is important to prevent cookie tampering
  	let auth = cookies.get(cookiename, {signed: true});
  	if (request.method === "POST") {
      let b = '';
      request.on('data', function(d) {b += d});
      request.on('end', function() {
        let fd = qs.parse(b);
        if (fd.password) auth_process(response, request, fd, cookies);
        else if (fd.dashdata) {
          // If cookies does not match accesstoken, don't send data
          if (auth == accountinfo.accesstoken) send_text(JSON.stringify(data), response);
          else send_text("Unauthorized", response);
        }
        else if (fd.settings) {
          if (auth == accountinfo.accesstoken) {
            // Attempt to save settings
            try {
              let settings = JSON.parse(fd.settings);
              data.settings = settings;
              send_text("Success!", response);
              save_info();
            } catch(err) {
              send_text("Bad format", response);
            }
          } else send_text("Unauthorized", response);
        }
        else send_data(response, request, false);
      });
    }
    if (request.method === "GET") {
  	  if (auth === accountinfo.accesstoken) send_data(response, request, true);
  	  else send_data(response, request, false);
    }
	}
}).listen(32899);

function get_file(contentType, filePath, response, request) {
  fs.readFile(filePath, function(error, content) {
    if (error) send_text('Invalid request.', response);
    else {
      response.writeHead(200, { 'Content-Type': contentType });
      response.end(content, 'utf-8');
    }
  });
}

function send_data(response, request, auth) {
  // if authentication failed check if request is allowed. Otherwise attempt to send send original request
  let filePath = auth ? request.url : auth_check(request.url);
  // If root page is requested & authentication successful send dashboard page
  if (filePath == '/') filePath = home + pages.dashboard;
  else filePath = home + filePath;
  let extname = (filePath.split('.').pop()).toLowerCase();
  let mimeTypes = {
        'html': 'text/html',
        'js': 'text/javascript',
        'css': 'text/css',
        'json': 'application/json',
        'png': 'image/png',
        'jpg': 'image/jpg'
  };
  let contentType = mimeTypes[extname] || 'text/plain';
  get_file(contentType, filePath, response, request);
}

function send_text(s, res) {
  res.writeHead(200, {
		'Content-Type': "text/plain"
	});
	res.write(s);
	res.end();
}

function send_redirect(page, res) {
	res.writeHead(302, {
		Location: page
	});
	res.end();
}

function auth_check(url) {
  let a = allowed.some((a)=>{return url.includes(a)});
  if (a) return url;
  else if (!accountinfo) return pages.setup;
  else return pages.login;
}

function auth_process(response, request, post, cookies) {
	// Signed = true is important
	if (post.password == accountinfo.passkey) {
	  cookies.set(cookiename, accountinfo.accesstoken, {
	  	signed: true,
	  	secure: false,
	  	maxAge: 86400000000,
	  	domain: cookiedomain
	  });
	  setTimeout(function() {
	    // Save info and attempt to start bot. Async important
	    save_info();
	    if (!botrunning) run_app();
	  },1000);
	  send_redirect(pages.dashboard, response);
	} else send_data(response, request, false);
}

function run_app() {
  // Namespace variables from data
  let margin = data.settings.margin || 0.97,
      markup = data.settings.markup || 0.01,
      trades = data.settings.trades || 100,
      limit = data.settings.limit || 10001,
      interval = data.settings.interval || 2,
      canrun = data.settings.canrun || 1;
      reset = data.settings.reset || 0;
  // If reset true delete account info and exit app
  if (reset == 1) {
    accountinfo = false;
    save_info();
    data.settings.reset = 0;
    return;
  } else {
    if (canrun == 1) run();
    else recurse(3);
    
    async function run() {
      try {
        debg('Running price check...');
        botrunning = true;
        await get_ads('get');
        let bm = await get_ad_prices(1);
        let sm = await get_ad_prices(0);
        let nps = get_marginal_prices(sm[0], bm[0]);
        data.competitorsell = sm[1];
        data.competitorbuy = bm[1];
        await update_ads();
        await get_ads('get');
        recurse(interval);
      } catch(err) {
        debg(err);
        recurse(3);
      }
    }
    async function get_ads(ac, adid, eq) {
      // Decrypt in-process api info.
      let ak = sjcl.decrypt(accountinfo.passkey, accountinfo.apikey);
      let as = sjcl.decrypt(accountinfo.passkey, accountinfo.apisecret);
      let data = [ac, ak, as];
      if (adid && eq && ac == 'post') data = [ac, ak, as, adid, eq];
      let options = {
        mode: 'text',
        pythonOptions: ['-u'],
        args: data
      };
      let shell = new Python("account_actions.py", options);
      shell.on('message', function (data) {
        if (ac == 'get') log_ads(data);
        else return;
      });
      shell.end(function (err) {
        if (err) console.log(err);
        else return;
      });
    }
    // UNUSED Function
    async function get_average() {
      try {
        let all = await got('https://localbitcoins.com/bitcoinaverage/ticker-all-currencies/');
        all = JSON.parse(all.body);
        let myr = all['MYR'];
        let ar = [];
        Object.keys(myr).forEach((k)=>{if (k.includes('avg')) ar.push(parseFloat(myr[k]))});
        let result = (ar.reduce((p, c) => p + c, 0 ) / ar.length).toFixed(2);
        return result;
      } catch(err) {d(err)}
    }
    // END
    async function get_ad_prices(t) {
      let p1 = await get_ad_data(t, 'my','malaysia','national-bank-transfer');
      let p2 = await get_ad_data(t, 'my','malaysia','transfers-with-specific-bank');
      let pr = p1.concat(p2);
      let h = p1[0] ? p1[0].price ? p1[0].price : null : null;
      let u = p2[0] ? p2[0].price ? p2[0].price : null : null;
      let t1 = [];
      if (h) t1.push(parseFloat(h));
      if (u) t1.push(parseFloat(u));
      let t2 = t ? Math.min(...t1) : Math.max(...t1);
      return [t2, pr];
    }
    async function get_ad_data(m, cc, cn, pm, r) {
      let url = `https://localbitcoins.com/${m < 1 ? 'sell' : 'buy'}-bitcoins-online/${cc}/${cn}/${pm}/.json`;
      let da = await got(url, {json: true});
      let blacklist = data.settings.blacklist || [];
      try {
        let prices = _.map(da.body.data.ad_list, (a) => {
              let f1 = parseInt(a.data.profile.trade_count) >= trades ? true : false;
              let f2 = parseInt(a.data.max_amount) >= limit ? true : false;
              let f3 = blacklist.includes(a.data.profile.username) ? false : true;
              if (f1 && f2 && f3) return {user: a.data.profile.username, price: parseFloat(a.data.temp_price)};
            });
        prices = _.filter(prices, p => {return p});
        if (m == 'sell') prices = prices.splice(0, 3);
        return prices;
      } catch(err) {
          if (!r) {
            setTimeout(function() {
              get_ad_data(m, cc, cn, pm, true);
            },1000);
          } else {
            console.log(err);
          }
        }
    }
    async function update_ads() {
      for (let a of data.ads) {
        if (a.id) {
          // Strict check
          let price;
          if (a.type == "SELL") price = data.sellprice;
          if (a.type == "BUY") price = data.buyprice;
          let ne = `(${price} - btc_in_usd*USD_in_MYR*1) + btc_in_usd*USD_in_MYR*1`;
          await get_ads('post', a.id, ne);
        }
      }
    }
  
    function get_marginal_prices(sm, bm) {
      let ten = function(n) {return Math.ceil((n+1)/10)*10};
      sm = parseFloat(sm);
      bm = parseFloat(bm);
      markup = parseFloat(markup);
      margin = parseFloat(margin);
      debg("Sell beat: "+sm);
      debg("Buy beat: "+bm);
      data.buyprice = Math.ceil(parseFloat(sm + markup).toFixed(2));
      let m = Math.ceil(parseFloat(((bm - sm) / bm) * 100));
      if (m < 3) data.sellprice = Math.ceil(parseFloat(data.buyprice / margin).toFixed(2));
      else data.sellprice = Math.ceil(parseFloat(bm - markup).toFixed(2));
      
      data.sellbeat = parseFloat(sm);
      data.buybeat = parseFloat(bm);
      data.margin = m.toFixed(2);
      return;
    }
    function log_ads(ads) {
      ads = JSON.parse(ads);
      ads = ads.data.ad_list;
      data.ads = [];
      ads.forEach((ad) => {
        let t = {};
        if (ad.data.trade_type) {
          let at = ad.data.trade_type;
          t.type = at.includes('BUY') ? 'BUY' : at.includes('SELL') ? 'SELL' : false;
        } else t.type = false;
        if (ad.data.temp_price) t.price = parseFloat(ad.data.temp_price);
        else t.price = false;
        if (ad.data.ad_id) t.id = ad.data.ad_id;
        else t.id = false;
        data.ads.push(t);
      });
      return;
    }
    function recurse(t) {
      setTimeout(function() {
        run_app();
      }, 1000 * 60 * t);
    }
  }
}

function debg(s) {if (debugmode) console.log(s)}