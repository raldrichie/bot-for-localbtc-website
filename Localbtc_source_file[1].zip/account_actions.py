import sys
import json
from lbcapi import api

def get_ads(config):
  conn = api.hmac(config[2], config[3])
  ads = conn.call('GET', '/api/ads/').json()
  print json.dumps(ads)
  
def update_equation(config):
  equate = config[5]
  data = {'price_equation': equate}
  conn = api.hmac(config[2], config[3])
  update = conn.call('POST', '/api/ad-equation/' + str(config[4]) + '/', data).json()
  print update
  

if (str(sys.argv[1]) == 'get'):
  get_ads(sys.argv)

if (str(sys.argv[1]) == 'post'):
  update_equation(sys.argv)